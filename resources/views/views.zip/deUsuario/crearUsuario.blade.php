@extends('plantillas.main')

@section('title','Usuarios')

@section('content')



    <div class="panel panel-default">

        <div class="panel-heading">

            <h1 class="panel-title">Registro de Usuarios</h1>

        </div>

        <div class="panel-body">


            <form action="{{route('usuariostore')}}" method="POST" autocomplete="on">
                @csrf

                <input type="hidden" value="{{ csrf_token() }}" name="_token" />


                <div class="form-group">


                    {!! Form::label('nombre','Nombres') !!}
                    {!! Form::text('nombre',null,['class'=>'form-control','placeholder'=>'Ingrese nombres','required']) !!}

                </div>

                <div class="form-group">

                    {!! Form::label('apellido','Apellidos') !!}
                    {!! Form::text('apellido',null,['class'=>'form-control','placeholder'=>'Ingrese apellidos','required']) !!}

                </div>

                <div class="form-group">

                    {!! Form::label('direccion','Direccción') !!}
                    {!! Form::text('direccion',null,['class'=>'form-control','placeholder'=>'Ingrese dirección','required']) !!}

                </div>



                <div class="form-group">

                    {!! Form::label('telefono','Telefono') !!}
                    {!! Form::number('telefono',null,['class'=>'form-control','placeholder'=>'Ingrese Teléfono','required']) !!}

                </div>


                <div class="form-group">

                    {!! Form::label('email','Email') !!}
                    {!! Form::email('email',null,['class'=>'form-control','placeholder'=>'Ingrese email','required']) !!}

                </div>


                <div class="form-group">

                    {!! Form::label('password','Password') !!}
                    {!! Form::password('password',['class'=>'form-control','placeholder'=>'*******','required']) !!}

                </div>

                <div class="form-group">

                    {!! Form::label('tipoRol','Tipo') !!}
                    {!! Form::select('tipoRol',[''=>'Seleccione un rol','1'=>'USUARIO','2'=>'ADMINISTRADOR'],null,['class'=>'form-control']) !!}

                </div>


                <div class="form-group" >

                    {!! Form::submit('Registrar',['class'=>'btn btn-primary']) !!}

                </div>

            </form>

        </div>




    </div>


@endsection


