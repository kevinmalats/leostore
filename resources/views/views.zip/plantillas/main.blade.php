<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>@yield('title','default') | Ingreso de usuarios  </title>

        <link rel="stylesheet" type="text/css" href="{{ asset('css/estilosCreaUsuarios.css') }}"   >


</head>
<body>
<!-- @include('plantillas.recursosbootstrap.nav')-->
<section>

    @yield('content')

</section>

</body>
</html>