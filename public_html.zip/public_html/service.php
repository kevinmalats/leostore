<?php

_cpanel-dcv-test-record="okM3Ac2TwHMSH1W3KYqlnh65GoYNHnyxgBZ4gNFGBbbKh8HZYkAQME5mP7hyNrhv”;

#incluimos la libreria nusoap.php que esta en el directorio en la carpeta lib
include('../lib/nusoap.php');

#indicamos que necesitamos establecer una conexion, la conexion esta embebida en el archivo conexionDatabase.php
require('../capadatos/conexiondatabase.php');

_cpanel-dcv-test-record="okM3Ac2TwHMSH1W3KYqlnh65GoYNHnyxgBZ4gNFGBbbKh8HZYkAQME5mP7hyNrhv”;

#urk para referirnos a nuestro servicio http://95.216.33.133/~leostore
$url = "http://95.216.33.133/~leostore/capalogicadenegocio/service.php";

#creamos un objeto del tipo nusoap_server, para crear un nuevo server
$servidor = new nusoap_server();

#Configurar nuestro wsdl, permitir que sea localizado, encabezado del webService
$servidor->configureWSDL("_Sistema Promo",$url);
$servidor->wsdl->schemaTargetNamespace = $url;
$servidor->soap_defencoding ='utf-8';


# FUNCION PARA CONSULTA DE PRODUCTOS ---------------------------------------
$servidor->register("consultaProductos",array("nombre"=>"xsd:string"),array("return"=>"xsd:string"),$url);
function consultaProductos($nombre)
{

$conexion = conectaBase();

if($nombre!="")
{
$sql = "select codigo, descripcion from tb_producto where Nombre = '$nombre'";
}
else{
$sql = "select codigo, descripcion from tb_producto";

}

$resp = mysqli_query($conexion,$sql);
$i=0;
$cadena = "<?xml version='1.0' encoding='utf-8'?>";
if($resp != null){

$cadena.="<producto>";
if(mysqli_num_rows($resp)>0)
{

	while ($row = mysqli_fetch_row($resp))
	{
		$cadena.="<productos>";
		$cadena.="<br>";
		$cadena.="<Codigo>".$row[0]."</Codigo>";
		$cadena.="<br>";
		$cadena.="<descripcion>".$row[1]."</descripcion>";
		$cadena.="</productos>";
		$i++;

	}
}
else{
	$cadena.= "<error> no hay datos</error>";
}
$cadena.="</producto>";
}
else{$cadena.= "<error> Error ".mysqli_error()."</error>";
}
$respuesta = new soapval('return','xsd:string',$cadena);
return $respuesta;
}


# FUNCION PARA INSERTAR PRODUCTOS ---------------------------------------
$servidor->register("insertarProductos",array("codigo"=>"xsd:string","nombre"=>"xsd:string",
"descripcion"=>"xsd:string","precio"=>"xsd:string","PrecioVenta"=>"xsd:string","idCategoria"=>"xsd:string"),array("return"=>"xsd:string"),$url);
function insertarProductos($codigo,$nombre,$descripcion,$precio_,$precioVenta,$idCategoria)
{

$conexion = conectaBase();

if(isset($codigo) && isset($nombre) && isset($descripcion) && isset($precio_) && !empty($precioVenta) && isset($idCategoria))
{


return "1";

}

else{

return "Unidad no insertada, datos incompletos - Codigo: ".$nombre.",Descripcion: ".$descripcion.",Precio: $".$precio_.",Precio_Venta: $".$precioVenta.",Categoria: ".$idCategoria;

}



}


# CONSULTA EROLES
$servidor->register("consultaRoles",array("key"=>"xsd:string"),array("return"=>"xsd:string"),$url);
function consultaRoles($key) #RECIBE EL PARAMETRO CLAVE..
{

#SE REALIZA LA CONEXION
$conexion = conectaBase(); 

#SE VALIDA CLAVE
if($key=="Kerty0934"){

$sql = "select id, nombre from tb_rol";

#SE EJECUTA LA CONSULTA
$resp = mysqli_query($conexion,$sql);
$i=0;


$cadena = "<?xml version='1.0' encoding='utf-8'?>";

# VALIDAR QUE DEVUELVA FILAS
if($resp != null){

$cadena.="<Roles>";

# DEVOLVIO FILAS
if(mysqli_num_rows($resp)>0)
{

# SE CREA LA ESTRUCTURA, RECORREMOS LAS FILAS
	while ($row = mysqli_fetch_row($resp))
	{
		$cadena.="<Roles>";
		$cadena.="<br>";
		$cadena.="<id>".$row[0]."</id>";
		$cadena.="<br>";
		$cadena.="<Nombre>".$row[1]."</Nombre>";
		$cadena.="</Roles>";
		$i++;

	}
}
else{
	$cadena.= "<error> no hay datos</error>";
}
$cadena.="</Roles>";
}
else{$cadena.= "<error> Error ".mysqli_error()."</error>";
}
$respuesta = new soapval('return','xsd:string',$cadena);
return $respuesta;
}

else
{

return "Clave incorrecta, acceso denegado....";

}

}





if(!isset($HTTP_RAW_POST_DATA))
	$HTTP_RAW_POST_DATA = file_get_contents('php://input');
$servidor->service($HTTP_RAW_POST_DATA);



?>