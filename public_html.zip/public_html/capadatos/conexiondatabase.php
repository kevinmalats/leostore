<?php
#phpinfo();
function conectaBase()
{

#parametros de conexion een variable llamada conectaParametros
$conectaParametros = mysqli_connect("leostore_leo","leoadmin1234","")or die(mysqli_error());

#definimos la base de datos y el nombre de la variable conectaParametros
mysqli_select_db($conectaParametros,"leostore_syspromo");
#or die ("Problemas al conectar con la base de datos");

return($conectaParametros);

}

?>