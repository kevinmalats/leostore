<?php
include("conexion.php");
$con = connect();

$id_empresa = $_GET['id_empresa'];
$id_empleado = $_GET['id_empleado'];

if(isset($_GET['id_empresa']) && isset($_GET['id_empleado']) && isset($_GET['tipo']))
{
	$id_empresa = $_GET['id_empresa'];
	$id_empleado = $_GET['id_empleado'];
	$tipo = $_GET['tipo'];
	
	$query = "select * from m_empresa where EMPRESA_ID = ".$id_empresa;
	$resp = mysqli_query($con, $query);
	if(mysqli_num_rows($resp)>0)
	{
		if($tipo == 0)	//Insertar o actualizar
		{
			if(isset($_GET['codigo']) && isset($_GET['apellido']) && isset($_GET['nombre']) && isset($_GET['cedula']) && isset($_GET['clave']) && isset($_GET['usuario']))
			{
				$codigo = $_GET['codigo'];
				$apellido = $_GET['apellido'];
				$nombre = $_GET['nombre'];
				$cedula= $_GET['cedula'];
				$usuario = $_GET['usuario'];
				$clave = $_GET['clave'];
				$query = "select * from m_empleado WHERE EMPLEADO_ID = '".$id_empleado."' and EMPRESA_ID = ".$id_empresa;
				$resp = mysqli_query($con, $query);
				if(mysqli_num_rows($resp)>0)	//ACTUALIZAR
				{
					$query = "update m_empleado set EMPLEADO_APE = '".$apellido."', EMPLEADO_NOM = '".$nombre."', EMPLEADO_CED = '".$cedula."', EMPLEADO_CLAVE = '".$clave."', EMPLEADO_TIPO = '".$codigo."' WHERE EMPLEADO_ID = '".$id_empleado."' and EMPRESA_ID = ".$id_empresa;
					$resp = mysqli_query($con, $query);
					if($resp)
					{
						$return['success'] = 1;
						$return['mensaje'] = "Registro actualizado correctamente.";
					}
					else
					{
						$return['success'] = 0;
						$return['mensaje'] = "Error al actualizar el registro.";
					}	
				}
				else	//INSERTAR
				{
					$query  = "insert into m_empleado (EMPLEADO_ID, EMPRESA_ID, EMPLEADO_CED, EMPLEADO_NOM, EMPLEADO_APE, EMPLEADO_TIPO, EMPLEADO_USUARIO, EMPLEADO_CLAVE)";
					$query .= "values('".$id_empleado."', ".$id_empresa.", '".$cedula."', '".$nombre."', '".$apellido."', '".$codigo."', '".$usuario."', '".$clave."')";
					$resp = mysqli_query($con, $query);
					if($resp)
					{
						$return['success'] = 1;
						$return['mensaje'] = "Registro insertado correctamente.";
					}
					else
					{
						$return['success'] = 0;
						$return['mensaje'] = "Error al insertar el registro.";
					}
				}
			}
			else
			{
				$return['success'] = 0;
				$return['mensaje'] = "No estan completos los campos de inserción o actualización";
			}
		}
		else	// proceso de eliminación
		{
			$query = "delete from m_empleado where EMPLEADO_ID = '".$id_empleado."' and EMPRESA_ID = ".$id_empresa;
			$resp = mysqli_query($con, $query);
			if($resp)
			{
				$return['success'] = 1;
				$return['mensaje'] = "Proceso de eliminación realizado correctamente";
			}
			else
			{
				$return['success'] = 0;
				$return['mensaje'] = "Error al eliminar al empleado.";
			}
		}
	}
	else
	{
		$return['success'] = 0;
		$return['mensaje'] = "La empresa no existe.";
	}	
}
else
{
	$return['success'] = 0;
	$return['mensaje'] = "No estan completos los campos de validación";
}

header("Content-type: application/json");
echo json_encode($return);
?>